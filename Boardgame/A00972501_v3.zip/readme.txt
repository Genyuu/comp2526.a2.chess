All chess piece icons were retrieved from 
"https://marcelk.net/chess/pieces/" February 27th, 2017

All credits to "C�rculo Lasallista de Ajedrez & Armando Hern�ndez Marroqu�n" at "http://www.enpassant.dk/chess/fontimg/leipzig.htm"
