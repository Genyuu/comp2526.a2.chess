package Chess;

/**
 * Work in progress.
 * 
 * @author Chris Cho, A00972501, Set A
 * @version 3.0
 */
public class Game {
    
}
